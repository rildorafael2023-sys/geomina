@echo off
rem Abre o GeoMina (versao portatil, sem instalar). Os dados ficam em %LOCALAPPDATA%\GeoMina.
cd /d "%~dp0"
start "" "%~dp0python\pythonw.exe" -m geomina %*
